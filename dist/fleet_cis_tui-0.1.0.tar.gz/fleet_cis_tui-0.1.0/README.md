# fleet-cis-tui

Cross-platform CLI/TUI tool for CIS benchmarks Fleet integration.

## Quick Start

Install with pipx (recommended):

```bash
pipx install fleet-cis-tui
```

Or install with pip:

```bash
pip install fleet-cis-tui
```

## Usage

### Interactive TUI (default)

Launch the interactive terminal interface:

```bash
fleet-cis-tui tui
```

- Use checkboxes to select platforms
- "Select All" to choose all available platforms  
- Press `G` or click "Generate" to create Fleet YAML files
- Press `Q` or Escape to quit

### Command Line Interface

**List available platforms:**
```bash
fleet-cis-tui list
```

**Generate single platform:**
```bash
fleet-cis-tui generate macos-15
```

**Generate multiple platforms:**
```bash
fleet-cis-tui generate macos-15 win-11
```

**Generate all platforms:**
```bash
fleet-cis-tui generate --all
```

**Custom output directory:**
```bash
fleet-cis-tui generate macos-15 --output /path/to/output
```

**Force overwrite existing files:**
```bash
fleet-cis-tui generate macos-15 --force
```

## What it does

This tool fetches CIS (Center for Internet Security) benchmark policies from the Fleet repository and transforms them into clean, Fleet-compatible YAML files:

1. **Discovers** CIS benchmark platforms from `fleetdm/fleet/ee/cis/`
2. **Fetches** raw policy YAML files from GitHub
3. **Transforms** data by extracting only essential fields:
   - `name` - Policy name
   - `platform` - Target platform (darwin, windows, etc.)
   - `description` - Policy description
   - `resolution` - How to fix the issue
   - `query` - SQL query to check compliance
4. **Outputs** clean `.yml` files in `./output/` directory

## Requirements

- Python 3.9+
- Internet connection (to fetch from GitHub)

## Development

Clone and install in development mode:

```bash
git clone <repository>
cd fleet-cis-tui
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -e ".[dev]"
```

Run tests:
```bash
pytest
```

Run linting:
```bash
ruff check src tests
mypy src
```

## License

MIT License